
  ------------------------------------------------------------------------

   CONTENTS 

       1. ABOUT ZOC
       2. DISTRIBUTION, COPYRIGHT
       3. INSTALLATION
       4. CONTACTING THE AUTHOR

  ------------------------------------------------------------------------



  ------------------------------------------------------------------------
    1. ABOUT ZOC for Windows 9X/ME/NT/2000/XP and OS/2
  ------------------------------------------------------------------------

    This is V4.x of ZOC.  ZOC is a high power terminal client for telnet,
    SSH, modem, ISDN, and more.  ZOC has a reputation of being one of
    the best telnet and SSH clients around.  Have a look at the feature 
    list and the screenshots at www.emtec.com and you will see why.

    The program is available from many online sources (BBSs, FTP, WWW,
    etc.).  It doubles as an evaluation version and full product, depending
    on if you have a software license code or not.
    
    Software license codes are available from special ZOC distributors
    and from mail order houses.  For information about buying ZOC please 
    check REGISTER.TXT and the order form in the Help menu.

    When you start ZOC without a software license code, the program will
    come up in evaluation mode.  In this mode it is fully functional and
    identical to the licensed version.  The only difference is that after
    the end of a file transfer the order form is shown.



  ------------------------------------------------------------------------
    2. DISTRIBUTION, COPYRIGHT
  ------------------------------------------------------------------------

    ZOC is (C) 1993-2004 by Markus Schmidt 

    This is a license summary -- see LICENSE.TXT for details.

    You may use and test the program for 30 days in evaluation mode. 
    Then you have to order a license code or remove it from your system.

    No warranty of any kind can be given for damage caused through ZOC 
    directly or indirectly or any other way. 

    The evaluation version of ZOC may be distributed freely via tele-
    communication, shareware dealers or as a free add on for hard- or 
    software products in form of an unmodified ZIP archive, or as 
    unzipped files in an single directory with the name beginning with
    "ZOC" and with no file added, removed or modified.

    The REXX processor in the Windows version of ZOC was licensed code 
    from Enterprise Alternatives, Inc.  If you wish to use REXX separately
    from ZOC, please check the orders section of the help file for 
    information of how to contact Enterprise Alternatives.

    The evaluation version may be put on shareware internet sites, and/or 
    included in shareware or magazine CDs if the following requirements 
    are met.

     * ZOC must not be used in an army environment or for purposes 
       that are related to the military or to arms production.

     * ZOC may be included on shareware CDs, magazine cover CDs or
       internet shareware archives if the ZIP/EXE file is left 
       intact or if all files from the ZIP file are provided in a 
       single directory the name of which begins with ZOC. 


 
  ------------------------------------------------------------------------
    3. INSTALLATION
  ------------------------------------------------------------------------

    To install ZOC just run SETUP.EXE. The windowed install program will 
    handle the rest.

    If you encounter problems of any kind, please try to install ZOC 
    into a fresh directory on your boot drive without importing files 
    from a prior ZOC version.

    Note: ZOC should not be installed over or importing from an existing 
    beta version of ZOC.



  ------------------------------------------------------------------------
    4. CONTACTING THE AUTHOR
  ------------------------------------------------------------------------

    All necessary addresses, phone numbers, email-addresses etc. can
    be found from the help menu of ZOC.

    Alternately you can show the help file directly by typing
    WINHELP ZOC.HLP (Windows) or VIEWHELP ZOC.HLP (OS/2).

